package com.example.api1_programacionmobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.api1_programacionmobile.ui.theme.Api1programacionmobileTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Api1programacionmobileTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    PantallaRecordatorios(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

@Composable
fun PantallaRecordatorios(modifier: Modifier = Modifier) {
    var filtroSeleccionado by remember { mutableStateOf("TODOS") }

    val recordatoriosFiltrados = recordatorios.filter { recordatorio ->
        filtroSeleccionado == "TODOS" ||
                recordatorio.prioridad.name == filtroSeleccionado
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Mis recordatorios",
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            BotonFiltro(
                texto = "Todos",
                valor = "TODOS",
                color = Color(0xFF52689B),
                seleccionado = filtroSeleccionado,
                modifier = Modifier.weight(1f)
            ) { filtroSeleccionado = it }

            BotonFiltro(
                texto = "Alta",
                valor = "ALTA",
                color = Color(0xFFD94343),
                seleccionado = filtroSeleccionado,
                modifier = Modifier.weight(1f)
            ) { filtroSeleccionado = it }

            BotonFiltro(
                texto = "Media",
                valor = "MEDIA",
                color = Color(0xFFE99A32),
                seleccionado = filtroSeleccionado,
                modifier = Modifier.weight(1f)
            ) { filtroSeleccionado = it }

            BotonFiltro(
                texto = "Baja",
                valor = "BAJA",
                color = Color(0xFF399568),
                seleccionado = filtroSeleccionado,
                modifier = Modifier.weight(1f)
            ) { filtroSeleccionado = it }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(recordatoriosFiltrados) { recordatorio ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = when (recordatorio.prioridad) {
                            Prioridad.ALTA -> Color(0xFFFFE0E0)
                            Prioridad.MEDIA -> Color(0xFFFFE0B2)
                            Prioridad.BAJA -> Color(0xFFDDF5E5)
                        }
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = recordatorio.titulo,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text("Categoría: ${recordatorio.categoria}")
                        Text("Prioridad: ${recordatorio.prioridad}")
                        Text("Estado: ${recordatorio.estado}")
                        Text(
                            text = "Color: ${coloresCategorias[recordatorio.categoria] ?: "Sin color"}"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BotonFiltro(
    texto: String,
    valor: String,
    color: Color,
    seleccionado: String,
    modifier: Modifier = Modifier,
    onClick: (String) -> Unit
) {
    Button(
        onClick = { onClick(valor) },
        modifier = modifier,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (seleccionado == valor) color else color.copy(alpha = 0.6f)
        )
    ) {
        Text(text = texto, fontSize = 10.sp)
    }
}

enum class Prioridad { BAJA, MEDIA, ALTA }

enum class EstadoRecordatorio { PENDIENTE, EN_PROGRESO, COMPLETADO }

sealed class EstadoValidacion {
    object Valido : EstadoValidacion()
    data class Invalido(val mensaje: String) : EstadoValidacion()
}

enum class CategoriaRecordatorio { ESTUDIO, TRABAJO, PERSONAL, SALUD }

data class Recordatorio(
    val id: Int,
    val titulo: String,
    val categoria: CategoriaRecordatorio,
    val prioridad: Prioridad,
    val estado: EstadoRecordatorio
)

val recordatorios = listOf(
    Recordatorio(
        id = 1,
        titulo = "Estudiar Kotlin",
        categoria = CategoriaRecordatorio.ESTUDIO,
        prioridad = Prioridad.ALTA,
        estado = EstadoRecordatorio.PENDIENTE
    ),
    Recordatorio(
        id = 2,
        titulo = "Preparar entrega",
        categoria = CategoriaRecordatorio.TRABAJO,
        prioridad = Prioridad.MEDIA,
        estado = EstadoRecordatorio.EN_PROGRESO
    ),
    Recordatorio(
        id = 3,
        titulo = "Sacar turno médico",
        categoria = CategoriaRecordatorio.SALUD,
        prioridad = Prioridad.BAJA,
        estado = EstadoRecordatorio.COMPLETADO
    )
)

val categorias = recordatorios.map { it.categoria }.toSet()

val recordatoriosPendientes = recordatorios.filter {
    it.estado == EstadoRecordatorio.PENDIENTE
}

val recordatoriosPrioridadAlta = recordatorios.filter {
    it.prioridad == Prioridad.ALTA
}

val coloresCategorias = mapOf(
    CategoriaRecordatorio.ESTUDIO to "Azul",
    CategoriaRecordatorio.TRABAJO to "Verde",
    CategoriaRecordatorio.PERSONAL to "Violeta",
    CategoriaRecordatorio.SALUD to "Rojo"
)

fun validarRecordatorio(recordatorio: Recordatorio): EstadoValidacion {
    return if (recordatorio.titulo.isBlank()) {
        EstadoValidacion.Invalido("El título no puede estar vacío")
    } else {
        EstadoValidacion.Valido
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Api1programacionmobileTheme {
        PantallaRecordatorios()
    }
}
